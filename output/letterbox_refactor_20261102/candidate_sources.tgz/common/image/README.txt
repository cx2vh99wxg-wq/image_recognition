公共图像预处理实现

letterbox_rgb888_impl.inc 由两端原有 pcie/csrc/preprocess.c 编译，不作为独立源文件构建。
对外仍使用各自 preprocess.h 中的 letterbox_simple 和 BOX_RECT 接口。

M 包装源定义 PERCEPTION_LETTERBOX_UNIT_SCALE_COPY=0，保留原逐像素最近邻路径。
S 包装源定义该值为 1，保留原有 scale==1、尺寸一致时的逐行拷贝分支。
除这项本来就存在的两端差异外，比例、补边、灰色填充、浮点截断、坐标收敛和字节顺序一致。

修改公共实现时两端都应重新编译；原有 Makefile 的传递头文件依赖会记录这个 .inc 文件。
本轮只做静态核对与编译，不运行 NPU、采集、车控或动作测试。
